class Rate < ActiveRecord::Base

end